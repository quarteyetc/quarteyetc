// Use this to customize the visual editor boot process
// Just mirror the options specified in your visual editor's config with the new
// options here.  This will completely override anything specified in your visual
// editor's boot process for that key, e.g. skin: 'something_else'
if (typeof(custom_visual_editor_options) == "undefined") {
  custom_visual_editor_options = {};
}
;
